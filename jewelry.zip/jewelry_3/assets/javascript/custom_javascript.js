AOS.init();

















    
// =============== start swiper card ============= 
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1, 
    spaceBetween: 30,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 3000, 
        disableOnInteraction: false,
    },
    breakpoints: {
        640: {
            slidesPerView: 1, 
            spaceBetween: 10,
        },
        768: {
            slidesPerView: 2, 
            spaceBetween: 20,
        },
        1024: {
            slidesPerView: 3, 
            spaceBetween: 30,
        },
    },
  });
  // =============== end swiper card ============= 
  









var mybutton = document.getElementById("scrollTopBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
};

// When the user clicks on the button, scroll to the top of the document
mybutton.onclick = function() {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
};















document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(".gold-card");
  const showMoreButton = document.getElementById("showMoreButton");
  const showLessButton = document.getElementById("showLessButton");

  const cardsToShow = 4; // Number of cards to show initially
  let visibleCards = cardsToShow;

  // Initial display setup
  cards.forEach((card, index) => {
      if (index < visibleCards) {
          card.classList.remove("d-none");
      }
  });

  // Show More button click
  showMoreButton.addEventListener("click", function () {
      visibleCards += cardsToShow;
      cards.forEach((card, index) => {
          if (index < visibleCards) {
              card.classList.remove("d-none");
          }
      });

      if (visibleCards >= cards.length) {
          showMoreButton.classList.add("d-none");
          showLessButton.classList.remove("d-none");
      }
  });

  // Show Less button click
  showLessButton.addEventListener("click", function () {
      visibleCards = cardsToShow;
      cards.forEach((card, index) => {
          if (index >= visibleCards) {
              card.classList.add("d-none");
          }
      });

      showMoreButton.classList.remove("d-none");
      showLessButton.classList.add("d-none");
  });
});











